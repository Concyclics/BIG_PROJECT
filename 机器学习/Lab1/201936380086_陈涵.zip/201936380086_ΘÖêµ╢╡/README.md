# codes for Experiment 1
### Author : 陈涵
### student code : 201936380086

## Files
### A. code for experiment
1. [lab1_code.py (python)](./lab1_code.py)
2. [lab1.ipynb (jupyter)](./lab1.jpynb)
3. [housing_scale.txt (dataset)](./housing_scale.txt)

### B. LaTex for report
1. [Lab1_report.tex](./Lab1_report.tex)
2. [lab1\_sto\_sam\_train.pdf (figure 1)](./lab1_sto_sam_train.pdf)
3. [lab1\_sto\_sam\_test.pdf (figure 2)](./lab1_sto_sam_test.pdf)
4. [SCUT.png](./SCUT.png)
5. [IEEEtran.cls](./IEEEtran.cls)